---
banner: "![[Attachments/Pasted image 20250602110938.png]]"
---
```search-bar 
search bar 
show bookmarks 
```
___

````col
```col-md
flexGrow=1
textAlign=center
===
[[Tasks]]

```
```col-md
flexGrow=1
textAlign=center
===
[[Index]]

```
```col-md
flexGrow=1
textAlign=center
===
[[Projects]]

```
````


*Edit the columns to add you quick links*
